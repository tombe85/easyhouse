# sweethomesw

Un buen manual de uso de git ( sencillo y asequible ) -> http://rogerdudler.github.io/git-guide/index.es.html
Manuel de contribuciones a un proyecto -> 				 http://git-scm.com/book/es/v1/Git-en-entornos-distribuidos-Contribuyendo-a-un-proyecto
